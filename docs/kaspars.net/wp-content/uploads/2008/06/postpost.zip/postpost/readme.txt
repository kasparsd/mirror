Plugin Name: PostPost
Plugin URI: http://www.douglaskarr.com/projects/postpost
Description: A plugin for users who wish to customize the content before and after every post on their blog and in their feed.
Author: Doug Karr
Author URI: http://www.douglaskarr.com
Version: 1.3
--------------------------

Version 1.3 by Kaspars (konstruktors.com/blog): added rotating post footers in feeds, that are displayed only if post exceeds certain number of words.

Installation
--------------------------
1. Upload all files to wp-content/plugins/postpost/
2. Activate the plugin on the plugin screen
3. Go to Options -> PostPost and update the fields with your information

Upgrading
--------------------------
1. If you are upgrading from an older version, delete your old prepostrss.php in wp-content/plugins/
2. Upload all files to wp-content/plugins/postpost
3. Your old options have been saved in the database and will appear when you visit options > PostPost

History
--------------------------
1.2.0 - Added the single page feature
1.1.1 - Added a page feature as well


Frequently Asked Questions
--------------------------


Bugs - Features - Support
--------------------------
Please report bugs via:
http://www.douglaskarr.com/contact-me/

If you need support, I will try and respond in a timely fashion, but currently I am trying to stick to bug requests and incorporating new features. You can contact me through the form for support.