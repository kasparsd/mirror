<?php
/*
Author: Douglas Karr
Author URI: http://www.douglaskarr.com
Description: Administrative options for PostPost
*/

load_plugin_textdomain('wppp',$path = 'wp-content/plugins/postpost');
$location = get_option('siteurl') . '/wp-admin/admin.php?page=postpost/postpost_admin.php';

/*Lets add some default options if they don't exist*/
add_option('wppp_letter_count', 0);
add_option('wppp_prepost', __('', 'wppp'));
add_option('wppp_postpost', __('', 'wppp'));
add_option('wppp_presingle', __('', 'wppp'));
add_option('wppp_postsingle', __('', 'wppp'));
add_option('wppp_prefeed', __('', 'wppp'));
add_option('wppp_postfeed', __('', 'wppp'));
add_option('wppp_prepage', __('', 'wppp'));
add_option('wppp_postpage', __('', 'wppp'));

/* update options */
if ('process' == $_POST['stage'])
{
update_option('wppp_letter_count', __($_POST['wppp_letter_count'], 'wppp'));
update_option('wppp_prepost', __($_POST['wppp_prepost'], 'wppp'));
update_option('wppp_postpost', __($_POST['wppp_postpost'], 'wppp'));
update_option('wppp_presingle', __($_POST['wppp_presingle'], 'wppp'));
update_option('wppp_postsingle', __($_POST['wppp_postsingle'], 'wppp'));
update_option('wppp_prefeed', __($_POST['wppp_prefeed'], 'wppp'));
update_option('wppp_postfeed', __($_POST['wppp_postfeed'], 'wppp'));
update_option('wppp_prepage', __($_POST['wppp_prepage'], 'wppp'));
update_option('wppp_postpage', __($_POST['wppp_postpage'], 'wppp'));
}

/*Get options for form fields*/
$wppp_letter_count = stripslashes(get_option('wppp_letter_count'));
$wppp_prepost = stripslashes(get_option('wppp_prepost'));
$wppp_postpost = stripslashes(get_option('wppp_postpost'));
$wppp_presingle = stripslashes(get_option('wppp_presingle'));
$wppp_postsingle = stripslashes(get_option('wppp_postsingle'));
$wppp_prefeed = stripslashes(get_option('wppp_prefeed'));
$wppp_postfeed = get_option('wppp_postfeed');
$wppp_prepage = stripslashes(get_option('wppp_prepage'));
$wppp_postpage = stripslashes(get_option('wppp_postpage'));

if (!is_array($wppp_postfeed)) {
	$wppp_postfeed[0] = stripslashes($wppp_postfeed);
} else {
	$wppp_postfeed = stripslashes_deep($wppp_postfeed);
}

?>

<style type="text/css">
.postpost textarea { width:100%; }
.postpost table { width:98%; }
.postpost table th { width:25%; text-align:right; }
</style>


<div class="wrap postpost">
  <h2><?php _e('PostPost Options', 'wppp') ?></h2>
  <form name="form1" method="post" action="<?php echo $location ?>&amp;updated=true">
	<input type="hidden" name="stage" value="process" />
    <table width="100%" cellspacing="2" cellpadding="5">
      <tr valign="top">
        <th scope="row"><?php _e('Before Every Post:') ?></th>
		<td><textarea name="wppp_prepost" id="wppp_prepost" rows="4" cols="50"><?php echo $wppp_prepost; ?></textarea></td>
      </tr>
      <tr valign="top">
        <th scope="row"><?php _e('After Every Post:') ?></th>
		<td><textarea name="wppp_postpost" id="wppp_postpost" rows="4" cols="50"><?php echo $wppp_postpost; ?></textarea></td>
      </tr>
      <tr valign="top">
        <th scope="row"><?php _e('Before Single Post on Page:') ?></th>
		<td><textarea name="wppp_presingle" id="wppp_presingle" rows="4" cols="50"><?php echo $wppp_presingle; ?></textarea></td>
      </tr>
      <tr valign="top">
        <th scope="row"><?php _e('After Single Post on Page:') ?></th>
		<td><textarea name="wppp_postsingle" id="wppp_postsingle" rows="4" cols="50"><?php echo $wppp_postsingle; ?></textarea></td>
      </tr>
	  <tr valign="top">
        <th scope="row"><?php _e('Before your Feed:') ?></th>
		<td><textarea name="wppp_prefeed" id="wppp_prefeed" rows="4" cols="50"><?php echo $wppp_prefeed; ?></textarea></td>
      </tr>

	  <tr valign="top">
        <th scope="row"></th>
		<td>
			<p><?php _e('Number of letters the post should contain in order for the feed footer to be added (for example, 700 letters is a two paragraph post):') ?>
			<input name="wppp_letter_count" id="wppp_letter_count" value="<?php echo $wppp_letter_count; ?>" /></p>
			<p><?php _e('For every post that meets the above criteria, one of these three feed footers will be added at random. Useful if you want rotate messages or advertising.') ?></p>
		</td>
      </tr>      
	  <tr valign="top">
        <th scope="row"><?php _e('After your Feed') ?> #1:</th>
		<td><textarea name="wppp_postfeed[]" id="wppp_postfeed1" rows="4" cols="50"><?php echo $wppp_postfeed[0]; ?></textarea></td>
      </tr>
	  <tr valign="top">
        <th scope="row"><?php _e('After your Feed') ?> #2:</th>
		<td><textarea name="wppp_postfeed[]" id="wppp_postfeed2" rows="4" cols="50"><?php echo $wppp_postfeed[1]; ?></textarea></td>
      </tr>
	  <tr valign="top">
        <th scope="row"><?php _e('After your Feed') ?> #3:</th>
		<td><textarea name="wppp_postfeed[]" id="wppp_postfeed3" rows="4" cols="50"><?php echo $wppp_postfeed[2]; ?></textarea></td>
      </tr>
	  <tr valign="top">
        <th scope="row"><?php _e('Before your Page:') ?></th>
		<td><textarea name="wppp_prepage" id="wppp_prepage" rows="4" cols="50"><?php echo $wppp_prepage; ?></textarea></td>
      </tr>
	  <tr valign="top">
        <th scope="row"><?php _e('After your Page:') ?></th>
		<td><textarea name="wppp_postpage" id="wppp_postpage" rows="4" cols="50"><?php echo $wppp_postpage; ?></textarea></td>
      </tr>
	</table>
    <p class="submit">
      <input type="submit" name="Submit" value="<?php _e('Update Options', 'wppp') ?> &raquo;" />
    </p>
  </form>
</div>
