﻿<?php
/*
Plugin Name: PostPost
Plugin URI: http://www.douglaskarr.com/projects/postpost
Description: A plugin for users who wish to customize the content before and after every post on their blog and in their feed or in their pages.
Author: Douglas Karr
Author URI: http://www.douglaskarr.com
Version: 1.3
*/

load_plugin_textdomain('wppp',$path = 'wp-content/plugins/postpost');

function wppp_updatecontent($content) {
	
	// retrieve the plugin options
		$wppp_letter_count = stripslashes(get_option('wppp_letter_count'));
		$wppp_prepost = stripslashes(get_option('wppp_prepost'));
		$wppp_postpost = stripslashes(get_option('wppp_postpost'));
		$wppp_presingle = stripslashes(get_option('wppp_presingle'));
		$wppp_postsingle = stripslashes(get_option('wppp_postsingle'));
		$wppp_prefeed = stripslashes(get_option('wppp_prefeed'));
		$wppp_postfeed = stripslashes_deep(get_option('wppp_postfeed'));
		$wppp_prepage = stripslashes(get_option('wppp_prepage'));
		$wppp_postpage = stripslashes(get_option('wppp_postpage'));
		
	if (strlen(strip_tags($content)) > $wppp_letter_count) {
		if(is_feed()) {
			if (is_array($wppp_postfeed)) {
				foreach ($wppp_postfeed as $key => $value) {
					$trimmed = trim($value);
					if (!empty($trimmed)) { 
						$feedads[] = $value;
					} 
				}
				$adcount = count($feedads) - 1;
				$showad = rand(0, $adcount);
				return $wppp_prefeed.$content.$feedads[$showad];	
			} else {
				return $wppp_prefeed.$content.$wppp_postfeed;
			}
		}
		if(is_page()) {
			return $wppp_prepage.$content.$wppp_postpage;
		}
		if(!is_page()) {
			return $wppp_prepost.$content.$wppp_postpost;
		}
		if(is_single()) {
			return $wppp_presingle.$content.$wppp_postsingle;
		}
	} else {
		return $content;
	}
}

function wppp_add_options_page() {
	add_options_page('PostPost Options', 'PostPost', 'manage_options', 'postpost/postpost_admin.php');
}

add_action('admin_menu', 'wppp_add_options_page');
add_filter('the_content', 'wppp_updatecontent', 1);

?>