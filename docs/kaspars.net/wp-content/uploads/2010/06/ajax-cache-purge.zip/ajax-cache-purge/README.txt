
INTRODUCTION

Most servers support time based cache with cache keys created out of cookie values. This plugin creates a unique "version number" cookie of site's content, which can be used for cache key.

Because of AJAX, the value of the cookie ("wp_cache_key_cookie") is verified and updated (if necessary) on every page request. The version number is set as a modification time (using 'touch') of a single 'key' file (located at /wp-content/uploads/cache-key.txt). If the content of the website changes (new post, comment, etc.), the modification time is updated, which in turn updates the cookie.

There are two files involved:

1) ajax-cache-purge.php -- 'touches' the key file.

2) key-check.php -- called by the AJAX request on every page load, checks for 'mtime' of cache-key.txt. If 'mtime' is different from the one currently stored in the cookie, a new cookie value is set.


EXAMPLE

For Nginx (/etc/nginx/sites-available/default):

fastcgi_cache_path 	/var/www/cache  levels=1:2  
			keys_zone=osc-cache:10m  
			inactive=2m max_size=2000m;

fastcgi_temp_path 	/var/www/cache/tmp;

server {
	listen 80 default;
	server_name _;

	# other stuff

	location ~ \.php$ {
		fastcgi_pass 		127.0.0.1:9000;
		fastcgi_index		index.php;

		include	/etc/nginx/fastcgi_params;
		
		# Cookies used for cache invalidation
		
		# Cookie is supplied by the plugin
		set $wp_cache_key_cookie 0;
		if ($http_cookie ~* "wp_cache_key_cookie[^=]*=([^;]+)(;|$)") {
			set $wp_cache_key_cookie wp_cache_key_cookie_$1;
		}
		
 		set $wordpress_logged_in 0;
		if ($http_cookie ~* "wordpress_logged_in_[^=]*=([^%]+)%7C") {
			set $wordpress_logged_in wordpress_logged_in_$1;
		}
		
		set $comment_author_email 0;
		if ($http_cookie ~* "comment_author_email_[^=]*=([^;]+)(;|$)") {
			set $comment_author_email comment_author_email_$1;
		}
		
		set $comment_author 0;
		if ($http_cookie ~* "comment_author_[^=]*=([^;]+)(;|$)") {
			set $comment_author comment_author_$1;
		}

        set $osc_cache_key $scheme$host|$request_uri|args=$args$http_if_modified_since|$wordpress_logged_in$comment_author_email$comment_author|$wp_cache_key_cookie;

		#add key in header for debugging
		#add_header	WP_KEY $osc_cache_key;

		fastcgi_pass_header	X-Accel-Expires;
		fastcgi_pass_header 	Set-Cookie;
		
		fastcgi_cache 		osc-cache;
		fastcgi_cache_key 	$osc_cache_key;
		fastcgi_cache_use_stale error timeout invalid_header http_500;
		fastcgi_cache_valid 	any  5m;
		
		fastcgi_ignore_client_abort on;
	}
}