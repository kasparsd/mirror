<?php
/*
Plugin Name: AJAX Cache Purge Cookie
Plugin URI: http://konstruktors.com/projects/
Description: On each page request an ajax call will check if cache needs to be invalidated. One can use that cookie for cache keys.
Author: Kaspars Dambis
Version: 0.1
Author URI: http://konstruktors.com/
*/


register_activation_hook(__FILE__, 'create_key_file_upon_activation');
function create_key_file_upon_activation() {
	$cache_key_file = get_cache_key_file();
	$handle = fopen($cache_key_file, 'w');
	fclose($handle);
	return;
}

function get_cache_key_file() {
	$uploads = wp_upload_dir();
	return $uploads['basedir'] . '/cache-key.txt';
}

function set_new_cache_key() {
	touch(get_cache_key_file());
	return true;
}

add_action('wp_footer', 'ajax_fresh_cache_key_check');
function ajax_fresh_cache_key_check() {
	$key_check_url = WP_PLUGIN_URL .'/'. basename(dirname(__FILE__)) . '/key-check.php';
	$key_cache_path = get_cache_key_file();
	$cache_key_file = str_replace($_SERVER["DOCUMENT_ROOT"], '', $key_cache_path);
	?>
	<!-- Cache key time: <?php echo date('r', filemtime($key_cache_path)); ?> -->
	<script type="text/javascript" >
	jQuery(document).ready(function($) {		
		var $timestamp = new Date().getTime();
		jQuery.post('<?php echo $key_check_url; ?>', { time: $timestamp, cache_key_file: '<?php echo $cache_key_file; ?>' }, function(response) {
			console.log(response);
		});
	});
	</script>
	<?php
}


/*
	Clear cache if something is edited
*/

$on_actions = array('publish_post', 'comment_post', 'delete_comment', 'edit_comment', 'delete_post', 'edit_post');
foreach ($on_actions as $action)
	add_action($action, 'set_new_cache_key');

if (!empty($_POST) && is_admin())
	set_new_cache_key();



/* 
	Add button under Tools in admin area
*/

add_action('admin_menu', 'menu_set_new_cache_key');
function menu_set_new_cache_key() {
	add_submenu_page('tools.php', 'Invalidate Cache', 'Invalidate Cache', 'activate_plugins', 'tool_set_new_cache_key', 'tool_set_new_cache_key');
}
function tool_set_new_cache_key() {
	if (set_new_cache_key()) 
		echo '<p>All Clear!</p>'; 
	else 
		echo '<p>Clearing Failed!</p>';
}


/*
	Add favorite action button
*/

add_filter('favorite_actions', 'favourit_set_new_cache_key');
function favourit_set_new_cache_key($actions) {
	$actions['tools.php?page=tool_set_new_cache_key'] = array('Invalidate Cache', 'activate_plugins');
	return $actions;
}

?>