<?php

$new_cache_key = filemtime($_SERVER["DOCUMENT_ROOT"] . $_POST['cache_key_file']);
$current_key = $_COOKIE['wp_cache_key_cookie'];

if ($current_key !== $new_cache_key && $new_cache_key !== 0)
	setcookie('wp_cache_key_cookie', $new_cache_key, time()+3600, '/');
	
echo "old:", $current_key, " new:", $new_cache_key;

?>