
Important:

-- Change $api_url to your api url in:
	/plugin/test-plugin-update/test-plugin-update.php and 
	/theme/portfolio-racer/inc/update.php

-- /api/plugins and /api/themes contain the same plugin with exactly the same version number. The only difference is that $packages inside /api/index.php inform WordPress that these are newer packages.
