Portfolio Racer
===============

Description
-----------

A WordPress theme to combine portfolio with a blog.


Features
--------




Changelog
---------

0.4 -- January 23, 2010
* Allow to filter <title> seperator

0.3 -- January 21, 2010

