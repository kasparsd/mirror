jQuery(document).ready(function() {
	jQuery('#comment').elastic();
});
