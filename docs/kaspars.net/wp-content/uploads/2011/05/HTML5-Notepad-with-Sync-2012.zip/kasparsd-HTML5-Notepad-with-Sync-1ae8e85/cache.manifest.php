<?php header('Content-Type: text/cache-manifest'); ?>
CACHE MANIFEST
# v20121

CACHE:
index.html
images/icon-doc.png
js/jquery.min.js
js/wysiwym/wysiwym.js
js/wysiwym/wysiwym.css
js/wysiwym/buttons.light.png
js/coreyti-showdown/showdown.js
js/pretty.js

NETWORK:
sync.php
logout.php