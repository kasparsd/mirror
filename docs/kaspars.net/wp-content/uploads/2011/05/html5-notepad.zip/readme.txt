HTML5 Notepad App
by Kaspars Dambis
http://konstruktors.com

Installation
============

1. Upload files to your server
2. Rename 'entries' folder to something random and harder to guess
3. Make that folder writable (CHMOD 0777)
4. Edit sync.php and specify your new DATA_DIR (the one you just renamed)
5. Change username and password to something unique
6. Done!

