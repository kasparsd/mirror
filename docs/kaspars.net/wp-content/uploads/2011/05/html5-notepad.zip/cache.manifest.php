<?php header('Content-Type: text/cache-manifest'); ?>
CACHE MANIFEST
# v3

CACHE:
index.html
jquery.min.js
images/icon-doc.png
images/cloud-pad.png

NETWORK:
ajax.php